#include <stdio.h>
#include <stdlib.h>
#include<assert.h>
#include<stdbool.h>

//typedef int QDataType;

int n;

typedef struct QueueNode{//����һ�����н�� 
	struct QueueNode *next;
	void* data;
}QNode;

typedef struct Que{
	QNode* head;
	QNode* tail;
}Queue;

void QueueInit(Queue* pq);
void QueueDestory(Queue* pq);
void Queuepush(Queue* pq,void* data);
void Queuepop(Queue* pq);
void QueueFront(Queue* pq);
void* QueueBack(Queue* pq);
//int QueueSize(Queue* pq);
bool QueueEmpty(Queue* pq);
void listmenu();
void QueueDestory2(Queue* pq);
void Queuetoppop(Queue *pq);
void QueueInsert(Queue* pq);
void Queuecreat(Queue* pq);


