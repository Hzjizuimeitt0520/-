#include <stdio.h>
#include <stdlib.h>
#include<stdbool.h>
#include<assert.h>
//typedef int STDataType;
//typedef int STDataType;

//typedef struct Stack{
// STDataType *a;//ָ��һ��ռ�ĵ�ַ 
// int top;//ջ��λ�� 
// int capacity;//���ÿռ� 
 
//}ST;
typedef struct SymbolStack{
 char *a;
 int SBtop;
 int SBcapacity;
}SBST;

typedef struct NumberStack{
 int *a;
 int NBtop;
 int NBcapacity;
}NBST;

//void StackInit(ST* ps);
//void destory(ST* ps);
//void Stackpush(ST* ps,STDataType x);
//void Stackpop(ST* ps);
//STDataType StackTop(ST* ps);
//bool STackEmpty(ST* ps);
//int StackSize(ST* ps);


void SBSTInit(SBST* ps);
void NBSTInit(NBST* ps);
void SBSTpush(SBST* ps,char c);
void NBSTpush(NBST* ps,int x);
char SBSTTop(SBST* ps);
int NBSTTop(NBST* ps);
bool SBSTStackEmpty(SBST* ps);
bool NBSTStackEmpty(NBST* ps);
int symbolcompare(SBST* ps,char n);
int Calculate(int num1,char ch,int num2);
