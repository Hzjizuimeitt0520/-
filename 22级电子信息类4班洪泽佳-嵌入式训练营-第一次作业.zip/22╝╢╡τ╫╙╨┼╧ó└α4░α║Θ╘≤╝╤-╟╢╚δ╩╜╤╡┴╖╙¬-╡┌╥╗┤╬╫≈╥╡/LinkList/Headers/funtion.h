#include<stdio.h>
#include<stdlib.h>
#include<assert.h>


typedef int SLDataType;

typedef struct SList{
 SLDataType data;
struct SList* next;
struct SList* prev;
}SL;

SL* SListInit();
void  SLInsert(SL*pos,SLDataType x);
SL* SListFind(SL*phead,SLDataType x);
void SListerase(SL*pos);
void SListchange(SL*pos,SLDataType x);
void SLPrint(SL*phead);
void SLTest();
void SListDestory(SL**phead);
