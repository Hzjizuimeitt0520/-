
#include<stdio.h>
#include<stdlib.h>
#include<assert.h>
#include"funtion.h"


SL* SListInit()

{
	SL*phead=(SL*)malloc(sizeof(SL));
	phead->next=phead;
	phead->prev=phead;
	return phead;
 } 
 //����λ��ǰ����
 void  SLInsert(SL*pos,SLDataType x)
 {
 	assert(pos);
 	SL*posprev=pos->prev;
 	SL*newnode=(SL*)malloc(sizeof(SL));
	 newnode->data=x;
 	posprev->next=newnode;
 	newnode->prev=posprev;
 	pos->prev=newnode;
 	newnode->next=pos;
 	
 	
  } 
  //����
  SL* SListFind(SL*phead,SLDataType x)
  {
  	assert(phead!=NULL);
  	SL*pos=phead;
  	while(pos->data!=x)
  	{
  		pos=pos->next;
	  }
	  return pos;
   } 
  
  void SListerase(SL*pos)
  {
  	assert(pos!=NULL);
  	SL*posprev=pos->prev;
  	SL*posnext=pos->next;
  	posprev->next=posnext;
  	posnext->prev=posprev;
  	free(pos);
  	pos=NULL;
  }
  void SListchange(SL*pos,SLDataType x)
  {
  	assert(pos!=NULL);
  	pos->data=x;
  }
   void SListDestory(SL**phead)
  {
  	assert(*phead!=NULL);
  	SL*cur=(*phead)->next;
  	SL*next=NULL;
  	while(cur!=*phead)
  	{
  		next=cur->next;
  		free(cur);
  		cur=next;
	  }
	  free(*phead);
	  *phead=NULL;
   } 
  
  //��ӡ
  void SLPrint(SL*phead)
  {
  	
  	SL*cur=phead->next;
  	while(cur!=phead)
  	{
  		printf("%d",cur->data);
  		cur=cur->next;
	  }
   } 
   void SLTest()
   {
   	SL*plist=SListInit();
   	//ͷ��
	   SLInsert(plist->next,2) ;SLInsert(plist->next,3);
	   //β��
	    SLInsert(plist,1); SLInsert(plist,4);
	    //�� ɾ 
		//SListerase();
		//��
		 //SListchange(SListFind(plist,1),0);
	   
	   SLPrint(plist);
	  
   }
