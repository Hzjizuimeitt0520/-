#ifndef___KEY_H__
#define___KEY_H__

unsigned int Key();

#endif