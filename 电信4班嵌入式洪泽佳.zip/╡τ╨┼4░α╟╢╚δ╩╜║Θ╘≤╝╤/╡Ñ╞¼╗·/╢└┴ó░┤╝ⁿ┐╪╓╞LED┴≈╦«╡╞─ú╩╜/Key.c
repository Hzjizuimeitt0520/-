//独立按键的模板
#include <REGX52.H>
#include"Delay.h"
unsigned int Key()
{
	unsigned char KeyNum;
	if(P3_1==0){Delay(20);while(P3_1==0);Delay(20);KeyNum=1;}
	if(P3_2==0){Delay(20);while(P3_2==0);Delay(20);KeyNum=2;}
	if(P3_3==0){Delay(20);while(P3_3==0);Delay(20);KeyNum=3;}
	if(P3_4==0){Delay(20);while(P3_4==0);Delay(20);KeyNum=4;}

   return KeyNum;
}