#include <REGX52.H>
#include"Timer0.h"
#include <INTRINS.H>//是一个可以用于写流水灯的库，里面有右移函数和左移函数
#include "Key.h"
#include "LCD1602.h"
//右移：unsigned char a=0x80;a=_crol_(a,1);比之前的那个左移右移多一个功能就是他会回到原来那个位置，如1000 0000 再左移的话 这个函数会使他变为0000 0001




unsigned char KeyNumber,LEDMode;

void main()
{
	
		P2=0xFE;
	
		Timer0_Init();
	
	while(1)
	{
	
		KeyNumber=Key();
		if(KeyNumber)
		{
			if(KeyNumber==1)
			{
			LEDMode++;
			if(LEDMode>=2){LEDMode=0;}
			
			}
		}
	
	}
}
		
		
 

void Timer0_Routine() interrupt 1
{
	 static unsigned int T0Count;
	T0Count++;
	TL0 = 0x18;
	TH0 = 0xFC;
	if(T0Count>=500)
	{
		T0Count=0;
		if(LEDMode==0)
		{
			 P2=_crol_(P2,1);
		}
			if(LEDMode==1)
		{
			 P2=_cror_(P2,1);
		}
	
	}
	
}

	
	
	

	