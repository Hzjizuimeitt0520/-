#ifndef__DELAY_H__
#define__DELAY_H__

void Delay(int x);

#endif