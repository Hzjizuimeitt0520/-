void Delay(int x)
{
	int i,j;
	while(x){
		
	i=2;
	j=269;
	do{
		while(--j);
	}while(--i);
x--;
	}

}