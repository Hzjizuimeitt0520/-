#include<stdio.h>
#include<stdlib.h>

void InsertSort(int k[],int n);
void Guibin(int* list1,int list1size,int* list2,int list2size);
void GuiSort(int k[],int n);
void swap(int k[],int low,int high);
int Partition(int k[],int low,int high);
void QSort(int k[],int low,int high);
void countSort(int* k,int size);
void mume();
//(int* k) input(int n);
