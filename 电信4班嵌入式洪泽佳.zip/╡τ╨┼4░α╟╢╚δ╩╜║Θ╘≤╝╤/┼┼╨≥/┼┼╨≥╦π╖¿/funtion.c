#include<stdio.h>
#include<stdlib.h>
#include"funtion.h"


void InsertSort(int k[],int n)
{
	int i,j,temp;
	for(i=1;i<n;i++)
	{
		if(k[i]<k[i-1])
		{
			temp=k[i];
			
			for(j=i-1;k[j]>temp;j--)
			{
				k[j+1]=k[j];
			}
			k[j+1]=temp;
		}
	}
}




//�����ǲ�����
void Guibin(int* list1,int list1size,int* list2,int list2size)
{
	int i=0;
	int j=0;
	int k=0;
	int* temp=(int*)calloc(list1size+list2size,sizeof(int));
	while(i<list1size&&j<list2size)
	{
		if(list1[i]<list2[j])
		{
			temp[k++]=list1[i++];
			
		}
		else
		{
			temp[k++]=list2[j++];
			
		}
		while(i<list1size)
		{
			temp[k++]=list1[i++];
		}
		while(j<list2size)
		{
			temp[k++]=list2[j++];
		}
	}
	
}

void GuiSort(int k[],int n)
{
	if(n>1)
	{
	  int *list1=k;
	  int list1size=n/2;
	  int *list2=k+n/2;
	  int list2size=n-list1size;
	  GuiSort(list1,list1size);
	  GuiSort(list2,list2size);
	  //�����ǲ����� 
	  Guibin(list1,list1size,list2,list2size);
	  
	  
	}

}










void swap(int k[],int low,int high)
{
	int temp;
	temp=k[low];
	k[low]=k[low];
	k[low]=k[high];
	k[high]=temp;
}


int Partition(int k[],int low,int high)
{
	int point;
	
	point=k[low];
	
	while(low<high)
	{
		while(low<high&&k[high]>=point)
		{
			high--;
		}
		swap(k,low,high);
		
			while(low<high&&k[low]<=point)
		{
			low--;
		}
		swap(k,low,high);
		
	}
	
	return low;
}



void QSort(int k[],int low,int high)
{
	int point;
	if(low<high)
	{
		point=Partition(k,low,high);
		QSort(k,low,point-1);
		QSort(k,point+1,high);
	}
}

void countSort(int* k,int size)
{
	//�������Сֵ �ҵ���Χ������һ��ռ��˷ѣ��������� 
	int i=0;
	int max=k[0],min=k[0];
	for(i=1;i<size;i++)
	{
		if(k[i]>max)
		{
			max=k[i];
			
		}
		if(k[i]<min)
		{
			min=k[i];
		}
	}
	
	//��¼����
	int length=max-min+1;
	int* temp=(int*)calloc(size,sizeof(int));
	
	for(i=0;i<size;i++)
	{
		temp[k[i]-min]++;
		
	}
	int j=0;
	for(i=0;i<length;i++)
	{
		while(temp[i]>0)
		{
			k[j]=i+min;
			j++;
			temp[i]--;
		}
		
	}
	
	free(temp);
	temp=NULL;
	
}


//(int* k) input(int n)
//{
//	
//	int k[n]={0};
//    int i;
//    printf("\n������%d������Ԫ�أ�\n",n);
//    for(i=0;i<n;i++)
//    {
//    	scanf("%d",&k[i]);
//	}
//	return k;
//
//}






//void QuickSort(int k[],int n)
//{
//	Qsort(k,0,n-1);
//}


void mume()
{
 printf("1.��������\n");
 printf("2.�鲢����\n");
 printf("3.��������\n");
 printf("4.��������\n");
 printf("5.�˳�\n");
} 

 
 






