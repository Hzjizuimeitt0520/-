#include <stdio.h>
#include <stdlib.h>
#include"funtion.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main()
{

 int i;
 
 int o;
 printf("���������鳤��:");
 scanf("%d", &o);

 int *a = (int*)malloc(o*sizeof(int));

 for ( i = 0; i < o; i++)
 {
 printf("��Ϊ�����%dԪ�ظ�ֵ:",i+1);
 scanf("%d", &a[i]);
 printf("%d\n",a[i]);
 }
	mume();
	while(1){
		int n=0;
 printf("����������ѡ��Ĺ��ܣ�");
 scanf("%d",&n); 
 switch(n){
  case 1:
  InsertSort(a,o);
  for(i=0;i<o;i++)
 {
  printf("%d",a[i]);
 }
 printf("\n");
  break;
  case 2:
   GuiSort(a,o);
  for(i=0;i<o;i++)
 {
  printf("%d",a[i]);
 }
  printf("\n");
  break;
  case 3:
   QSort(a,0,n-1);
  for(i=0;i<o;i++)
 {
  printf("%d",a[i]);
 }
  printf("\n");
  break;
  case 4:
   countSort(a,o);
  for(i=0;i<o;i++)
 {
  printf("%d",a[i]);
 }
  printf("\n");
  break;
  case 5:
   return;
}
 
}
	
	
}
